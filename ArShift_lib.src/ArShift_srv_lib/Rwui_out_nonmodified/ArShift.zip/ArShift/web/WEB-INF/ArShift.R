# ********************************************************************* #
# This function is a part of the R library created by                   #
#                       *Aleksandr B. Sahakyan*                         #
# while working in the group of                                         #
#                        *Michele Vendruscolo*.                         #
# The library as a whole is designed to facilitate a wide variety of    #
# manipulations of protein structure PDB files and NMR parameter        #
# calculations. This code can be used after requesting a permission.    #      
# For questions and bug reports please contact -- aleksahak@cantab.net  #
# Last modified:                             21 March, 2010, Cambridge  #
# ********************************************************************* #
#########################################################################
# This is the interfacing script to the ArShift program, which predicts #
# 1H chemical shifts of the Tyr and Phe aromatic rings.                 #
# ********************************************************************* #
# For questions and bug reports please contact -- aleksahak@cantab.net  #
# Last modified:                              15 Sept, 2010, Cambridge  #
#########################################################################

### ENTER COMMAND (cmd):
 #title        = "first_test" 
 #pdbname      = "a7_b03.pdb"
 #experdata    = NULL #a7_out.shift
 #examine      = 0 #0 for all, 1,2,3 etc... for specific ones
 #pdbtype      = "almost" # "complex", "almost", "medium", "simple"
 #seqshift     = 0
 #rereference  = FALSE #TRUE/FALSE
 #outorder     = "bytype" #"bytype", "byseq", "byshift"
 #outputname   = "out.txt"
 #bias         = 1        # positive number to bias color palette
### EXAMPLE:
#cmd <- 'pdbname="example.pdb", title="Ubiquitin_1", experdata="example.exp", bias=1, examine=1, pdbtype="almost", seqshift=0, rereference=FALSE, outorder="bytype", outputname="out.txt"'

  
# # # FLAGS # # # FLAGS # # # FLAGS # # # FLAGS # # # FLAGS
IsThisWebServer = FALSE
# # # FLAGS # # # FLAGS # # # FLAGS # # # FLAGS # # # FLAGS

if(IsThisWebServer==TRUE) {
  if(title=="")    {title="Not specified."}
  if(pdbname=="")  {stop("The PDB file is not uploaded")}
  outputname  =  "out.txt"
  prefix.ws   =  "../../../"
  load("../../../ArShift_lib/ArShift.ini")
} else {
  load("ArShift_lib/ArShift.ini")
  # generates and reads the commands based on created cmd line
  eval(parse(text=paste("ArShift.cmd(",cmd,")")))
  load("ArShift.cmd")
  file.remove("ArShift.cmd")
  if(pdbname=="")  {stop("The PDB file is not uploaded")}
  # 
  prefix.ws <- NULL 
}
if(experdata==""){experdata=NULL}
# # # FLAGS # # # FLAGS # # # FLAGS # # # FLAGS # # # FLAGS


# START

OUT <- "NOTE: * * * ArShift * * * ArShift * * *  "
OUT[2] <- paste("NOTE: Title -- ", title, sep="")
write(OUT, file="process_info.txt")

# # # # # # # # ####### PDB file examination: ####### # # # # # # # # # #

  isNMR <- isNMRpdb(pdbname)
  OUT <- c(OUT, paste("NOTE: Hydrogen atom presence - ",isNMR$isH,sep=""))
         print(OUT[length(OUT)]) # PRINTOUT
  OUT <- c(OUT, paste("NOTE: Number of structures in the model - ",isNMR$Nmodels,sep=""))
         print(OUT[length(OUT)]) # PRINTOUT
  models2analyse <- 1:isNMR$Nmodels

  if(isNMR$isH!=TRUE){
    OUT <- c(OUT,"ERROR: Please add hydrogens to your molecule!")
           stop(OUT[length(OUT)]) # PRINTOUT
  }
  if(isNMR$Nmodels > 1 & examine==0){
    OUT <- c(OUT, paste("NOTE: All the ",isNMR$Nmodels,
             " models will be analyzed with the shifts averaged!",sep=""))
             print(OUT[length(OUT)]) # PRINTOUT
    models2analyse <- 1:isNMR$Nmodels
  }

  if(isNMR$Nmodels > 1 & examine > 0 & examine <= isNMR$Nmodels){
    OUT <- c(OUT,paste("NOTE: Only the structure ",examine," will be analyzed.",sep=""))
           print(OUT[length(OUT)]) # PRINTOUT
    isNMR$Nmodels <- 1
    models2analyse <- examine
  }
  
  write(OUT[3:length(OUT)], file="process_info.txt", append=TRUE)

# # # # # # # # ######## End of PDB file examination: ####### # # # # # # 



# Loading the parameters:
OUT <- c(OUT, "NOTE: Loading the parameters..."); print(OUT[length(OUT)])
write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
load(paste(prefix.ws,PATH.PAR,"ArShift.par",sep=""))
OUT <- c(OUT, "NOTE: Parameters are loaded."); print(OUT[length(OUT)])
write(OUT[length(OUT)], file="process_info.txt", append=TRUE)


#########################################################################
RESID <- SEQ <- NUCL <- NULL
ChSh.pred <- SE_fit <- SD_train <- list(NULL)
ChSh.pred[[maxnumofentry+1]] <- 
SE_fit[[maxnumofentry+1]]    <- 
SD_train[[maxnumofentry+1]]  <- NA
#########################################################################

count.tried.model <- 1
for(model in models2analyse){
  list.entry <- 1

  # Generating the file for a particular model (model.pdb)
  file.copy(pdbname, "model.pdb", overwrite=TRUE)
  isNMRpdb("model.pdb", model.num=model)

  # ###### Parsing the PDB file: ######
  if(pdbtype=="complex"){
    OUT <- c(OUT, "NOTE: Parsing with a 'complex' flag."); print(OUT[length(OUT)])
    write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
    parsed.pdb <- pdbparser.complex("model.pdb")$PROTEIN
    parsed.pdb$resSeq <- parsed.pdb$resSeq + seqshift
  }
  if(pdbtype=="almost"){
    OUT <- c(OUT, "NOTE: Parsing with an 'almost' flag."); print(OUT[length(OUT)])
    write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
    parsed.pdb <- pdbparser.almost("model.pdb")
    parsed.pdb$resSeq <- parsed.pdb$resSeq + seqshift
  }
  if(pdbtype=="medium"){
    OUT <- c(OUT, "NOTE: Parsing with a 'medium' flag."); print(OUT[length(OUT)])
    write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
    parsed.pdb <- pdbparser.medium("model.pdb")
    parsed.pdb$resSeq <- parsed.pdb$resSeq + seqshift
  }
  if(pdbtype=="simple"){  # At present is the same as medium
    OUT <- c(OUT, "NOTE: Parsing with a 'simple' flag."); print(OUT[length(OUT)])
    write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
    parsed.pdb <- pdbparser.simple("model.pdb")
    parsed.pdb$resSeq <- parsed.pdb$resSeq + seqshift
  }
  # Converting the $name convention to the one used in ALMOST, which is the
  #    first record in topology.lib:
  OUT <- c(OUT, "NOTE: Converting the PDB naming convention."); print(OUT[length(OUT)])
  write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
  record.variants <- pdbProc(parsed.pdb, topology=proc.topol)
  parsed.pdb <- convert.topology(parsed.pdb=parsed.pdb, proc.topol=proc.topol,
                                 record.variants=record.variants)
  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

  # # # # # # # # # # # # # # # # 
  if(count.tried.model==1){
    # Finding out the Phe/Tyr group presence:
    # Will be done for only the first model, and of course the rest are
    # assumed to be the same:
    Ar.res <- Ar.seq <- NULL
    phe.pres <- amac.find(parsed.pdb, AmAc="PHE")
    if(phe.pres$num!=0){
      Ar.res <- c(Ar.res, rep(phe.pres$resName, phe.pres$num))
      Ar.seq <- c(Ar.seq, phe.pres$resSeq)
      OUT <- c(OUT, paste("NOTE: ",phe.pres$info,sep="")); print(OUT[length(OUT)])
      write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
    }
    tyr.pres <- amac.find(parsed.pdb, AmAc="TYR")
    if(tyr.pres$num!=0){
      Ar.res <- c(Ar.res, rep(tyr.pres$resName, tyr.pres$num))
      Ar.seq <- c(Ar.seq, tyr.pres$resSeq)
      tyr.pres$num <- NULL
      OUT <- c(OUT, paste("NOTE: ",tyr.pres$info,sep="")); print(OUT[length(OUT)])
      write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
    }

  } else { #of if(count.tried.model==1)
    OUT <- c(OUT, paste("NOTE: Model ",model," of ",isNMR$Nmodels,".",sep="")); print(OUT[length(OUT)])
    write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
  }
  # # # # # # # # # # # # # # # # 

  OUT <- c(OUT, "NOTE: Extracting the terms for prediction..."); print(OUT[length(OUT)])
  write(OUT[length(OUT)], file="process_info.txt", append=TRUE)


  OUT <- c(OUT, "NOTE: Predicting chemical shifts..."); print(OUT[length(OUT)])
   write(OUT[length(OUT)], file="process_info.txt", append=TRUE)


  for(ar.ind in 1:length(Ar.seq)){

    if(Ar.res[ar.ind]=="PHE"){
        # nucl="HD"
        a <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="PHE", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HD1", readlib.dih=readlib.dih, arealR=6.5)
        b <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="PHE", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HD2", readlib.dih=readlib.dih, arealR=6.5)
        av.df <- average.pars(DataToFit.m1=a, DataToFit.m2=b, proc.topol=proc.topol)
        av.df <- addCos(Data=av.df, ang="PHI")
        av.df <- addCos(Data=av.df, ang="PSI")
        av.df <- addCos(Data=av.df, ang="CHI1")
        av.df <- addCos(Data=av.df, ang="CHI2")
        av.df <- addMergeDist(Data=av.df)
        av.df <- addROT(Data=av.df)
        #options(warn=-1)
        pr.lm <- predict.lm(object=PHE_HD, newdata=av.df, type='response', se.fit=TRUE)
        rm(a, b, av.df)
        # Filtering anomalous results, by setting them to NA:
        if(pr.lm$fit<PHE_HD_mincs & pr.lm$fit>PHE_HD_maxcs){pr.lm$fit <- NA}
    
       if(count.tried.model==1){
        RESID <- c(RESID, Ar.res[ar.ind])
        SEQ <- c(SEQ, Ar.seq[ar.ind])
        NUCL <- c(NUCL, "HD")
       }
        ChSh.pred[[list.entry]] <- c(ChSh.pred[[list.entry]], as.vector(pr.lm$fit))
        SE_fit[[list.entry]] <- c(SE_fit[[list.entry]], as.vector(pr.lm$se.fit))
        SD_train[[list.entry]] <- c(SD_train[[list.entry]], as.vector(pr.lm$residual.scale))
        
        list.entry <- list.entry + 1

        # nucl="HE"
        a <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="PHE", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HE1", readlib.dih=readlib.dih, arealR=6.5)
        b <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="PHE", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HE2", readlib.dih=readlib.dih, arealR=6.5)
        av.df <- average.pars(DataToFit.m1=a, DataToFit.m2=b, proc.topol=proc.topol)
        av.df <- addCos(Data=av.df, ang="PHI")
        av.df <- addCos(Data=av.df, ang="PSI")
        av.df <- addCos(Data=av.df, ang="CHI1")
        av.df <- addCos(Data=av.df, ang="CHI2")
        av.df <- addMergeDist(Data=av.df)
        av.df <- addROT(Data=av.df)
        #options(warn=-1)
        pr.lm <- predict.lm(object=PHE_HE, newdata=av.df, type='response', se.fit=TRUE)
        rm(a, b, av.df)
        # Filtering anomalous results, by setting them to NA:
        if(pr.lm$fit<PHE_HE_mincs & pr.lm$fit>PHE_HE_maxcs){pr.lm$fit <- NA}

       if(count.tried.model==1){
        RESID <- c(RESID, Ar.res[ar.ind])
        SEQ <- c(SEQ, Ar.seq[ar.ind])
        NUCL <- c(NUCL, "HE")
       }
        ChSh.pred[[list.entry]] <- c(ChSh.pred[[list.entry]], as.vector(pr.lm$fit))
        SE_fit[[list.entry]] <- c(SE_fit[[list.entry]], as.vector(pr.lm$se.fit))
        SD_train[[list.entry]] <- c(SD_train[[list.entry]], as.vector(pr.lm$residual.scale))

        list.entry <- list.entry + 1

        # nucl="HZ"
        av.df <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="PHE", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HZ", readlib.dih=readlib.dih, arealR=6.5)
        av.df <- addCos(Data=av.df, ang="PHI")
        av.df <- addCos(Data=av.df, ang="PSI")
        av.df <- addCos(Data=av.df, ang="CHI1")
        av.df <- addCos(Data=av.df, ang="CHI2")
        av.df <- addMergeDist(Data=av.df)
        av.df <- addROT(Data=av.df)
        #options(warn=-1)
        pr.lm <- predict.lm(object=PHE_HZ, newdata=av.df, type='response', se.fit=TRUE)
        rm(av.df)
        # Filtering anomalous results, by setting them to NA:
        if(pr.lm$fit<PHE_HZ_mincs & pr.lm$fit>PHE_HZ_maxcs){pr.lm$fit <- NA}

       if(count.tried.model==1){
        RESID <- c(RESID, Ar.res[ar.ind])
        SEQ <- c(SEQ, Ar.seq[ar.ind])
        NUCL <- c(NUCL, "HZ")
       }
        ChSh.pred[[list.entry]] <- c(ChSh.pred[[list.entry]], as.vector(pr.lm$fit))
        SE_fit[[list.entry]] <- c(SE_fit[[list.entry]], as.vector(pr.lm$se.fit))
        SD_train[[list.entry]] <- c(SD_train[[list.entry]], as.vector(pr.lm$residual.scale))

        list.entry <- list.entry + 1 
    }

    if(Ar.res[ar.ind]=="TYR"){
        # nucl="HD"
        a <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="TYR", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HD1", readlib.dih=readlib.dih, arealR=6.5)
        b <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="TYR", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HD2", readlib.dih=readlib.dih, arealR=6.5)
        av.df <- average.pars(DataToFit.m1=a, DataToFit.m2=b, proc.topol=proc.topol)
        av.df <- addCos(Data=av.df, ang="PHI")
        av.df <- addCos(Data=av.df, ang="PSI")
        av.df <- addCos(Data=av.df, ang="CHI1")
        av.df <- addCos(Data=av.df, ang="CHI2")
        av.df <- addMergeDist(Data=av.df)
        av.df <- addROT(Data=av.df)
        #options(warn=-1)
        pr.lm <- predict.lm(object=TYR_HD, newdata=av.df, type='response', se.fit=TRUE)
        rm(a, b, av.df)
        # Filtering anomalous results, by setting them to NA:
        if(pr.lm$fit<TYR_HD_mincs & pr.lm$fit>TYR_HD_maxcs){pr.lm$fit <- NA}
    
       if(count.tried.model==1){
        RESID <- c(RESID, Ar.res[ar.ind])
        SEQ <- c(SEQ, Ar.seq[ar.ind])
        NUCL <- c(NUCL, "HD")
       }
        ChSh.pred[[list.entry]] <- c(ChSh.pred[[list.entry]], as.vector(pr.lm$fit))
        SE_fit[[list.entry]] <- c(SE_fit[[list.entry]], as.vector(pr.lm$se.fit))
        SD_train[[list.entry]] <- c(SD_train[[list.entry]], as.vector(pr.lm$residual.scale))
        
        list.entry <- list.entry + 1

        # nucl="HE"
        a <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="TYR", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HE1", readlib.dih=readlib.dih, arealR=6.5)
        b <- Ar.get.single.dframe(parsed.pdb=parsed.pdb, proc.topol=proc.topol, record.variants=record.variants, AmAc="TYR", resSeqnum=Ar.seq[ar.ind], whichNMRnucl="HE2", readlib.dih=readlib.dih, arealR=6.5)
        av.df <- average.pars(DataToFit.m1=a, DataToFit.m2=b, proc.topol=proc.topol)
        av.df <- addCos(Data=av.df, ang="PHI")
        av.df <- addCos(Data=av.df, ang="PSI")
        av.df <- addCos(Data=av.df, ang="CHI1")
        av.df <- addCos(Data=av.df, ang="CHI2")
        av.df <- addMergeDist(Data=av.df)
        av.df <- addROT(Data=av.df)
        #options(warn=-1)
        pr.lm <- predict.lm(object=TYR_HE, newdata=av.df, type='response', se.fit=TRUE)
        rm(a, b, av.df)
        # Filtering anomalous results, by setting them to NA:
        if(pr.lm$fit<TYR_HE_mincs & pr.lm$fit>TYR_HE_maxcs){pr.lm$fit <- NA}

       if(count.tried.model==1){
        RESID <- c(RESID, Ar.res[ar.ind])
        SEQ <- c(SEQ, Ar.seq[ar.ind])
        NUCL <- c(NUCL, "HE")
       }
        ChSh.pred[[list.entry]] <- c(ChSh.pred[[list.entry]], as.vector(pr.lm$fit))
        SE_fit[[list.entry]] <- c(SE_fit[[list.entry]], as.vector(pr.lm$se.fit))
        SD_train[[list.entry]] <- c(SD_train[[list.entry]], as.vector(pr.lm$residual.scale))

        list.entry <- list.entry + 1
    }
  } # of   for(ar.ind in 1:length(Ar.seq))

  count.tried.model <- count.tried.model + 1
} # of for(model in models2analyse)

file.remove("model.pdb")

#########################################################################
list.entry <- list.entry-1
#RESID; SEQ; NUCL
ChSh.pred <- ChSh.pred[1:list.entry]
SE_fit    <-    SE_fit[1:list.entry]
SD_train  <-  SD_train[1:list.entry]

# Averaging the data obtained for multiple conformers
Pred.CS               <- sapply(ChSh.pred, FUN=function(i){mean(i,na.rm=TRUE)}, simplify=TRUE)
Pred.sefit            <- sapply(SE_fit,    FUN=function(i){mean(i,na.rm=TRUE)}, simplify=TRUE)
Pred.SDresidual.train <- sapply(SD_train,  FUN=function(i){mean(i,na.rm=TRUE)}, simplify=TRUE)


#########################################################################
## Filtering out the erroneous and violating predictions + reformating data

violating.shift.ind <- which(is.na(Pred.CS))
if(length(violating.shift.ind)>0){
  Pred.CS[violating.shift.ind] <- "xxxxxx"
  Pred.CS[-violating.shift.ind] <- format(round(as.numeric(Pred.CS[-violating.shift.ind]),3),nsmall=3)
} else {
  Pred.CS <- format(round(Pred.CS,3),nsmall=3)
}

violating.shift.ind <- which(Pred.sefit>999.99)
if(length(violating.shift.ind)>0){
  Pred.sefit[violating.shift.ind] <- "xxxxxxx"
  Pred.sefit[-violating.shift.ind] <- format(round(as.numeric(Pred.sefit[-violating.shift.ind]),3),nsmall=3)
} else {
  Pred.sefit <- format(round(Pred.sefit,3),nsmall=3)
}

violating.shift.ind <- which(Pred.SDresidual.train>999.99)
if(length(violating.shift.ind)>0){
  Pred.SDresidual.train[violating.shift.ind] <- "xxxxxx"
  Pred.SDresidual.train[-violating.shift.ind] <- format(round(
                                      as.numeric(Pred.SDresidual.train[-violating.shift.ind]),3),nsmall=3)
} else {
  Pred.SDresidual.train <- format(round(as.numeric(Pred.SDresidual.train),3),nsmall=3)
}

# RESID; SEQ; NUCL; Pred.CS; Pred.sefit; Pred.SDresidual.train

#########################################################################
# # # # Reading in the experimental data
if(length(experdata)!=0){
  OUT <- c(OUT, "NOTE: Processing the experimental data."); print(OUT[length(OUT)])
  write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
  exp.data <- readLines(experdata)

  # dummy and blank line exclusion is also added.
  comment.rows <- unique(c(grep("#", exp.data, fixed=TRUE),  
                           which(exp.data==""),
                           which(exp.data==" "),
                           which(exp.data=="  "),
                           which(exp.data=="   "),
                           which(exp.data=="    "),
                           which(exp.data=="     "),
                           which(exp.data=="      ")  ))

  if(length(comment.rows!=0)){ 
    exp.data <- exp.data[-comment.rows] 
  }

  exp.amac <- exp.seq <- exp.nucl <- exp.shift <- NULL

  # # # # 
  for(i in 1:length(exp.data)){
    line <- linesplit(exp.data[i])
    if(length(line)==4){
      amacic    <- as.character(line[1])
      exp.amac  <- c(exp.amac, amacic)
      exp.seq   <- c(exp.seq, as.numeric(line[2]))
      nuclic    <- as.character(line[3])
      # switching to internal convention:
      if(amacic=="PHE"& nuclic=="HD1"){nuclic<-"HD"}     
      if(amacic=="PHE"& nuclic=="HD2"){nuclic<-"HD"}
      if(amacic=="PHE"& nuclic=="HE1"){nuclic<-"HE"}
      if(amacic=="PHE"& nuclic=="HE2"){nuclic<-"HE"}
      if(amacic=="PHE"& nuclic=="HZ") {nuclic<-"HZ"}
      if(amacic=="TYR"& nuclic=="HD1"){nuclic<-"HD"}
      if(amacic=="TYR"& nuclic=="HD2"){nuclic<-"HD"}
      if(amacic=="TYR"& nuclic=="HE1"){nuclic<-"HE"}
      if(amacic=="TYR"& nuclic=="HE2"){nuclic<-"HE"}
      exp.nucl  <- c(exp.nucl, nuclic)
      exp.shift <- c(exp.shift, as.numeric(line[4]))
    }
  };rm(i)
  # # # # 

  Exp.CS <- Exp_Pred.CS <- rep(NA, length(NUCL))

  for(i in 1:length(exp.shift)) {
    position <-  which(RESID == exp.amac[i] &
                       NUCL  == exp.nucl[i] & 
                       SEQ   == exp.seq[i]   )
    if(length(position)!=0){
      Exp.CS[position] <- round(exp.shift[i], 3)
      prediction <- as.numeric(Pred.CS[position])
      if(!is.na(prediction)){
        Exp_Pred.CS[position] <- exp.shift[i]-prediction
      }
    } else {
      OUT <- c(OUT, "ERROR: Some of the exp. data records do not match the structure.")
       write(OUT[length(OUT)], file="process_info.txt", append=TRUE)
      stop(OUT[length(OUT)])
    } 
  }

  Exp.CS.nonfilt <- Exp.CS

  ndx <- which(is.na(Exp.CS))
  if(length(ndx)!=0){
   Exp.CS[ndx]  <- "xxxxx"
   Exp.CS[-ndx] <- format(round(as.numeric(Exp.CS[-ndx]),3),nsmall=3)
  } else {
   Exp.CS <- format(round(as.numeric(Exp.CS),3),nsmall=3)  
  }
  ndx <- which(is.na(Exp_Pred.CS))
  if(length(ndx)!=0){
   Exp_Pred.CS[ndx]  <- "xxxxx"
   Exp_Pred.CS[-ndx] <- format(round(as.numeric(Exp_Pred.CS[-ndx]),3),nsmall=3)
  } else {
   Exp_Pred.CS <- format(round(as.numeric(Exp_Pred.CS),3),nsmall=3)  
  }
  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

  # # # REREFERENCING
  if(rereference==TRUE){
    Pred.CS.num <- as.numeric(Pred.CS)
    # rereferencing proton chemical shifts:
    h.reref.ind <- which(!is.na(Pred.CS.num) & !is.na(Exp.CS.nonfilt))
    exp.reref  <- Exp.CS.nonfilt[h.reref.ind]
    pred.reref <- Pred.CS.num[h.reref.ind]
    if(length(exp.reref)>minRerefNum) {
      lm.reref <- lm(formula = exp.reref ~ 1, offset = pred.reref)
      Pred.CS.num <- Pred.CS.num + lm.reref$coefficients[1]
    }
    # recalculating errors
    Exp_Pred.CS <- Exp.CS.nonfilt-Pred.CS.num

    # reformating back
    na.pred.CS <- which(is.na(Pred.CS.num))
    if(length(na.pred.CS)>0){
      Pred.CS.num[na.pred.CS] <- "xxxxx"
      Pred.CS.num[-na.pred.CS] <- format(round(as.numeric(Pred.CS.num[-na.pred.CS]),3),nsmall=3)
    } else {
      Pred.CS.num <- format(round(as.numeric(Pred.CS.num),3),nsmall=3)
    }
    Pred.CS <- Pred.CS.num
    na.err.CS <- which(is.na(Exp_Pred.CS))
    if(length(na.err.CS)>0){
     Exp_Pred.CS[na.err.CS]  <- "xxxxx" # 5x, not 6x as the one above
     Exp_Pred.CS[-na.err.CS] <- format(round(as.numeric(Exp_Pred.CS[-na.err.CS]),3),nsmall=3)
    } else {
     Exp_Pred.CS <- format(round(as.numeric(Exp_Pred.CS),3),nsmall=3)  
    }
    #
  }
  # # # END OF REREFERENCING

  # RESID; SEQ; NUCL; Pred.CS; Pred.sefit; Pred.SDresidual.train; Exp.CS; Exp_Pred.CS

  # Generating the Probs and Stars data objects that comment on probabilities
  Exp_Pred.CS.num <- as.vector(sapply(Exp_Pred.CS, fun5, simplify=TRUE))
  Probs <- Stars <- rep("xxxxx", length(Exp_Pred.CS.num))
  for(SEQ.i in unique(SEQ)) {
    is <- which(SEQ==SEQ.i & !is.na(Exp_Pred.CS.num))
    if(length(is)!=0) {
      P.data <- getP(AMC=ResidueName(unique(RESID[is]), capitalize=FALSE,
                     threeletter=TRUE, oneletter = FALSE),
                     NCL=NUCL[is], De_c=Exp_Pred.CS.num[is], er.data=er.data)
      Probs[is] <- format(round(as.numeric(P.data$Prob),3),nsmall=3)  
      Stars[is] <- paste(rep("*", P.data$Stars), collapse="")
      rm(P.data)
    }
    rm(is)   
  }; rm(SEQ.i)

  # Generating chimera_cmd.txt file with UCSF Chimera command to color residues
  # according to their probabilities:
  colfun <- colorRampPalette(c("red","orange","yellow","green",5,"blue"), bias=bias)
  colors <- colfun(500)
  prob.range <- seq(from=0, to=1, by=0.002001)
  # plotting pallete:
  jpeg(quality=100, height=500, width=500, filename="protein_prob_palette.jpg")
    plot(x=prob.range,y=rep(0,500), col=colors, cex=5, pch=3, ylim=c(-0.1,0.1),
         main=paste("Bias = ", bias,sep=""))
  dev.off()
  #
  chimera.cmd <- NULL
  for(SEQ.i in unique(SEQ)){
    is <- which(SEQ==SEQ.i & Probs!="xxxxx")[1]
    if(length(is)!=0) {
      prb <- as.numeric(Probs[is]) 
      colind <- which(abs(prob.range-prb) == min(abs(prob.range-prb)))  
      chimera.cmd <- c(chimera.cmd," color ",colors[colind]," :",SEQ.i,";")
      rm(prb, colind)
    }
    rm(is)
  }; rm(SEQ.i, colors, colfun, prob.range)
  
  write(paste(chimera.cmd, collapse=""), file="chimera_cmd.txt")
  rm(chimera.cmd)


 
  # Printing out the results:
  if(outorder=="bytype"){ # Prints results odered by type.
    RESULTS.rep <- 
    c( "NOTE:                (o:     PRINTING OUT THE RESULTS:     :o)   ",
    paste("NOTE:  ","  ","RESID","  ","SEQ ","","NUCL"," ","ChSh(pred)"," ",
            "SE_fit"," ","SD_train"," ","ChSh(exp)"," ","D(e-p)"," ","   P "," ","    Np ",sep=""),
    paste(rep("RESULT:", length(NUCL))," ; ",
          RESID," ; ",
          format(SEQ,nsmall=0)," ; ",
          NUCL," ;  ",
          Pred.CS,"  ; ",
          Pred.sefit," ; ",
          Pred.SDresidual.train,"  ; ",
          Exp.CS," ;  ",
          Exp_Pred.CS," ; ",
          Probs," ; ",
          Stars
          ,sep=""))
  }
  if(outorder=="byseq"){ # Prints results odered by sequence number.
    byseq.ord <- order(SEQ)
    RESULTS.rep <- 
    c( "NOTE:                (o:     PRINTING OUT THE RESULTS:     :o)   ",
    paste("NOTE:  ","  ","RESID","  ","SEQ ","","NUCL"," ","ChSh(pred)"," ",
            "SE_fit"," ","SD_train"," ","ChSh(exp)"," ","D(e-p)",sep=""),
    paste(rep("RESULT:", length(NUCL))," ; ",
          RESID[byseq.ord]," ; ",
          format(SEQ,nsmall=0)[byseq.ord]," ; ",
          NUCL[byseq.ord]," ;  ",
          Pred.CS[byseq.ord],"  ; ",
          Pred.sefit[byseq.ord]," ; ",
          Pred.SDresidual.train[byseq.ord],"  ; ",
          Exp.CS[byseq.ord]," ;  ",
          Exp_Pred.CS[byseq.ord]," ; ",
          Probs[byseq.ord]," ; ",
          Stars[byseq.ord]
          ,sep=""))
  }
  if(outorder=="byshift"){ # Prints results odered by sequence number.
    byshift.ord <- order(as.numeric(Pred.CS))
    RESULTS.rep <- 
    c( "NOTE:                (o:     PRINTING OUT THE RESULTS:     :o)   ",
    paste("NOTE:  ","  ","RESID","  ","SEQ ","","NUCL"," ","ChSh(pred)"," ",
            "SE_fit"," ","SD_train"," ","ChSh(exp)"," ","D(e-p)",sep=""),
    paste(rep("RESULT:", length(NUCL))," ; ",
          RESID," ; ",
          format(SEQ,nsmall=0)[byshift.ord]," ; ",
          NUCL[byshift.ord]," ;  ",
          Pred.CS[byshift.ord],"  ; ",
          Pred.sefit[byshift.ord]," ; ",
          Pred.SDresidual.train[byshift.ord],"  ; ",
          Exp.CS[byshift.ord]," ;  ",
          Exp_Pred.CS[byshift.ord]," ; ",
          Probs[byshift.ord]," ; ",
          Stars[byshift.ord]
          ,sep=""))
  }

  rm(Probs, Stars, Exp_Pred.CS.num, fun5, er.data, getP)

} else {  # of if(length(experdata)!=0) => experimental data does not exist!!!


  if(outorder=="bytype"){ # Prints results odered by type.
    RESULTS.rep <- 
    c( "NOTE:      (o:     PRINTING OUT THE RESULTS:   :o)   ",
    paste("NOTE:  ","  ","RESID","  ","SEQ "," ","NUCL"," ","ChSh(pred)"," ",
          "SE_fit"," ","SD_train"," ",sep=""),
    paste(rep("RESULT:", length(NUCL))," ; ",
          RESID," ; ",
          format(SEQ,nsmall=0)," ; ",
          NUCL," ; ",
          Pred.CS," ; ",
          Pred.sefit," ; ",
          Pred.SDresidual.train
          ,sep=""))
  }
  if(outorder=="byseq"){ # Prints results odered by thype.
    byseq.ord <- order(as.numeric(DFrame[,"RESSEQ"]))
    RESULTS.rep <- 
    c( "NOTE:      (o:     PRINTING OUT THE RESULTS:   :o)   ",
    paste("NOTE:  ","  ","RESID","  ","SEQ "," ","NUCL"," ","ChSh(pred)"," ",
          "SE_fit"," ","SD_train"," ",sep=""),
    paste(rep("RESULT:", length(NUCL))," ; ",
          RESID[byseq.ord]," ; ",
          format(SEQ,nsmall=0)[byseq.ord]," ; ",
          NUCL[byseq.ord]," ; ",
          Pred.CS[byseq.ord]," ; ",
          Pred.sefit[byseq.ord]," ; ",
          Pred.SDresidual.train[byseq.ord]
          ,sep=""))
  }
  if(outorder=="byshift"){ # Prints results odered by thype.
    byshift.ord <- order(as.numeric(Pred.CS))
    RESULTS.rep <- 
    c( "NOTE:      (o:     PRINTING OUT THE RESULTS:   :o)   ",
    paste("NOTE:  ","  ","RESID","  ","SEQ "," ","NUCL"," ","ChSh(pred)"," ",
          "SE_fit"," ","SD_train",sep=""),
    paste(rep("RESULT:", length(NUCL))," ; ",
          RESID[byshift.ord]," ; ",
          format(SEQ,nsmall=0)[byshift.ord]," ; ",
          NUCL[byshift.ord]," ; ",
          Pred.CS[byshift.ord]," ; ",
          Pred.sefit[byshift.ord]," ; ",
          Pred.SDresidual.train[byshift.ord]
          ,sep=""))
  }
}
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

OUT <- c(OUT, RESULTS.rep, 
         "NOTE: ArShift - Good luck!                    ",
         "NOTE: For problem and bug reports contact - aleksahak@cantab.net ",
         "NOTE: N.B. Please, attach all the related files to the e-mail.  ")

write(OUT, file=outputname)
print("NOTE: Output file is written!")
write("NOTE: Output file is written!", file="process_info.txt", append=TRUE)
  
# DONE (P added) Last Mod. 20 Sep, 2010