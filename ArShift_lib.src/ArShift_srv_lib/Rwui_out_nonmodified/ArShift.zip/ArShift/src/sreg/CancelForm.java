package sreg;


import org.apache.struts.action.ActionForm;

/**
 * Form bean 
 *
 * @author Richard Newton
 */
public  class CancelForm extends ActionForm {
    
    public CancelForm() { }
    
}
